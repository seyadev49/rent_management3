
import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';
import {
  Building2,
  Plus,
  Edit,
  Trash2,
  MapPin,
  DollarSign,
  Users,
  Eye
} from 'lucide-react';

interface Property {
  id: number;
  name: string;
  address: string;
  city: string;
  subcity: string;
  woreda: string;
  property_type: string;
  total_units: number;
  occupied_units: number;
  created_at: string;
}

interface PropertyUnit {
  id: number;
  unit_number: string;
  floor_number: number;
  room_count: number;
  monthly_rent: number;
  deposit: number;
  is_occupied: boolean;
}

const Properties: React.FC = () => {
  const [properties, setProperties] = useState<Property[]>([]);
  const [selectedProperty, setSelectedProperty] = useState<Property | null>(null);
  const [propertyUnits, setPropertyUnits] = useState<PropertyUnit[]>([]);
  const [showAddModal, setShowAddModal] = useState(false);
  const [showUnitsModal, setShowUnitsModal] = useState(false);
  const [loading, setLoading] = useState(true);
  const { token } = useAuth();
  const { addToast } = useToast();

  const [formData, setFormData] = useState({
    name: '',
    address: '',
    city: '',
    subcity: '',
    woreda: '',
    property_type: 'apartment',
    description: ''
  });

  useEffect(() => {
    fetchProperties();
  }, []);

  const fetchProperties = async () => {
    try {
      const response = await fetch('/api/properties', {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });

      if (!response.ok) {
        throw new Error('Failed to fetch properties');
      }

      const data = await response.json();
      setProperties(data.properties || []);
    } catch (error) {
      addToast('Failed to load properties', 'error');
    } finally {
      setLoading(false);
    }
  };

  const fetchPropertyUnits = async (propertyId: number) => {
    try {
      const response = await fetch(`/api/units?propertyId=${propertyId}`, {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });

      if (!response.ok) {
        throw new Error('Failed to fetch property units');
      }

      const data = await response.json();
      setPropertyUnits(data.units || []);
    } catch (error) {
      addToast('Failed to load property units', 'error');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const response = await fetch('/api/properties', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify(formData),
      });

      if (!response.ok) {
        throw new Error('Failed to create property');
      }

      addToast('Property created successfully', 'success');
      setShowAddModal(false);
      setFormData({
        name: '',
        address: '',
        city: '',
        subcity: '',
        woreda: '',
        property_type: 'apartment',
        description: ''
      });
      fetchProperties();
    } catch (error) {
      addToast('Failed to create property', 'error');
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleViewUnits = async (property: Property) => {
    setSelectedProperty(property);
    await fetchPropertyUnits(property.id);
    setShowUnitsModal(true);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Properties</h1>
          <p className="text-gray-600">Manage your rental properties</p>
        </div>
        <button
          onClick={() => setShowAddModal(true)}
          className="bg-blue-600 text-white px-4 py-2 rounded-lg flex items-center space-x-2 hover:bg-blue-700"
        >
          <Plus className="w-4 h-4" />
          <span>Add Property</span>
        </button>
      </div>

      {/* Properties Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {properties.map((property) => (
          <div key={property.id} className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center space-x-2">
                <Building2 className="w-6 h-6 text-blue-500" />
                <h3 className="text-lg font-semibold text-gray-900">{property.name}</h3>
              </div>
              <div className="flex space-x-2">
                <button
                  onClick={() => handleViewUnits(property)}
                  className="p-1 text-gray-500 hover:text-blue-600"
                >
                  <Eye className="w-4 h-4" />
                </button>
                <button className="p-1 text-gray-500 hover:text-blue-600">
                  <Edit className="w-4 h-4" />
                </button>
                <button className="p-1 text-gray-500 hover:text-red-600">
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex items-center text-sm text-gray-600">
                <MapPin className="w-4 h-4 mr-2" />
                {property.address}, {property.city}
              </div>
              <div className="flex items-center text-sm text-gray-600">
                <Users className="w-4 h-4 mr-2" />
                {property.occupied_units} / {property.total_units} units occupied
              </div>
              <div className="text-sm text-gray-500 capitalize">
                {property.property_type}
              </div>
            </div>

            <div className="mt-4 pt-4 border-t">
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-500">
                  Created: {new Date(property.created_at).toLocaleDateString()}
                </span>
                <div className="text-right">
                  <div className="text-sm font-medium text-green-600">
                    {((property.occupied_units / property.total_units) * 100).toFixed(0)}% Occupied
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {properties.length === 0 && (
        <div className="text-center py-12">
          <Building2 className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <p className="text-gray-500">No properties found. Add your first property!</p>
        </div>
      )}

      {/* Add Property Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-md mx-4">
            <h2 className="text-xl font-semibold mb-4">Add New Property</h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Property Name
                </label>
                <input
                  type="text"
                  name="name"
                  required
                  value={formData.name}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Address
                </label>
                <input
                  type="text"
                  name="address"
                  required
                  value={formData.address}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    City
                  </label>
                  <input
                    type="text"
                    name="city"
                    required
                    value={formData.city}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Subcity
                  </label>
                  <input
                    type="text"
                    name="subcity"
                    required
                    value={formData.subcity}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Woreda
                </label>
                <input
                  type="text"
                  name="woreda"
                  required
                  value={formData.woreda}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Property Type
                </label>
                <select
                  name="property_type"
                  value={formData.property_type}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                >
                  <option value="apartment">Apartment</option>
                  <option value="house">House</option>
                  <option value="commercial">Commercial</option>
                  <option value="office">Office</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Description
                </label>
                <textarea
                  name="description"
                  rows={3}
                  value={formData.description}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div className="flex space-x-4 pt-4">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="flex-1 px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                >
                  Create Property
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Units Modal */}
      {showUnitsModal && selectedProperty && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-4xl mx-4 max-h-[80vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-semibold">
                Units in {selectedProperty.name}
              </h2>
              <button
                onClick={() => setShowUnitsModal(false)}
                className="text-gray-500 hover:text-gray-700"
              >
                ×
              </button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {propertyUnits.map((unit) => (
                <div key={unit.id} className="border rounded-lg p-4">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="font-medium">Unit {unit.unit_number}</h3>
                    <span
                      className={`px-2 py-1 text-xs rounded ${
                        unit.is_occupied
                          ? 'bg-red-100 text-red-800'
                          : 'bg-green-100 text-green-800'
                      }`}
                    >
                      {unit.is_occupied ? 'Occupied' : 'Available'}
                    </span>
                  </div>
                  <div className="space-y-1 text-sm text-gray-600">
                    <p>Floor: {unit.floor_number}</p>
                    <p>Rooms: {unit.room_count}</p>
                    <p className="font-medium text-gray-900">
                      Rent: ${unit.monthly_rent}/month
                    </p>
                    <p>Deposit: ${unit.deposit}</p>
                  </div>
                </div>
              ))}
            </div>

            {propertyUnits.length === 0 && (
              <div className="text-center py-8">
                <p className="text-gray-500">No units found for this property</p>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default Properties;
