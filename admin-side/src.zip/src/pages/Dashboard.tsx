
import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';
import {
  Building2,
  Users,
  FileText,
  CreditCard,
  AlertTriangle,
  TrendingUp,
  Calendar,
  DollarSign
} from 'lucide-react';

interface DashboardStats {
  totalProperties: number;
  totalTenants: number;
  activeContracts: number;
  totalRevenue: number;
  overduePayments: number;
  pendingMaintenance: number;
  expiringContracts: number;
  collectionRate: number;
}

interface RecentActivity {
  id: number;
  type: string;
  description: string;
  date: string;
}

const Dashboard: React.FC = () => {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [recentActivity, setRecentActivity] = useState<RecentActivity[]>([]);
  const [loading, setLoading] = useState(true);
  const { token } = useAuth();
  const { addToast } = useToast();

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      const response = await fetch('/api/dashboard', {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });

      if (!response.ok) {
        throw new Error('Failed to fetch dashboard data');
      }

      const data = await response.json();
      setStats(data.stats);
      setRecentActivity(data.recentActivity || []);
    } catch (error) {
      addToast('Failed to load dashboard data', 'error');
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  const statCards = [
    {
      name: 'Total Properties',
      value: stats?.totalProperties || 0,
      icon: Building2,
      color: 'bg-blue-500',
    },
    {
      name: 'Total Tenants',
      value: stats?.totalTenants || 0,
      icon: Users,
      color: 'bg-green-500',
    },
    {
      name: 'Active Contracts',
      value: stats?.activeContracts || 0,
      icon: FileText,
      color: 'bg-purple-500',
    },
    {
      name: 'Monthly Revenue',
      value: `$${stats?.totalRevenue?.toLocaleString() || 0}`,
      icon: DollarSign,
      color: 'bg-yellow-500',
    },
    {
      name: 'Overdue Payments',
      value: stats?.overduePayments || 0,
      icon: AlertTriangle,
      color: 'bg-red-500',
    },
    {
      name: 'Pending Maintenance',
      value: stats?.pendingMaintenance || 0,
      icon: AlertTriangle,
      color: 'bg-orange-500',
    },
    {
      name: 'Expiring Contracts',
      value: stats?.expiringContracts || 0,
      icon: Calendar,
      color: 'bg-indigo-500',
    },
    {
      name: 'Collection Rate',
      value: `${stats?.collectionRate || 0}%`,
      icon: TrendingUp,
      color: 'bg-teal-500',
    },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
        <p className="text-gray-600">Overview of your rent management system</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {statCards.map((stat) => {
          const Icon = stat.icon;
          return (
            <div key={stat.name} className="bg-white rounded-lg shadow p-6">
              <div className="flex items-center">
                <div className={`p-3 rounded-lg ${stat.color}`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">{stat.name}</p>
                  <p className="text-2xl font-semibold text-gray-900">{stat.value}</p>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Recent Activity */}
      <div className="bg-white shadow rounded-lg">
        <div className="px-6 py-4 border-b border-gray-200">
          <h2 className="text-lg font-medium text-gray-900">Recent Activity</h2>
        </div>
        <div className="p-6">
          {recentActivity.length > 0 ? (
            <div className="space-y-4">
              {recentActivity.map((activity) => (
                <div key={activity.id} className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                  <div className="flex-1">
                    <p className="text-sm text-gray-900">{activity.description}</p>
                    <p className="text-xs text-gray-500">
                      {new Date(activity.date).toLocaleDateString()}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-gray-500 text-center py-8">No recent activity</p>
          )}
        </div>
      </div>

      {/* Quick Actions */}
      <div className="bg-white shadow rounded-lg">
        <div className="px-6 py-4 border-b border-gray-200">
          <h2 className="text-lg font-medium text-gray-900">Quick Actions</h2>
        </div>
        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <button className="p-4 border border-gray-200 rounded-lg hover:bg-gray-50 text-left">
              <Building2 className="w-8 h-8 text-blue-500 mb-2" />
              <h3 className="font-medium text-gray-900">Add Property</h3>
              <p className="text-sm text-gray-500">Add a new property to manage</p>
            </button>
            <button className="p-4 border border-gray-200 rounded-lg hover:bg-gray-50 text-left">
              <Users className="w-8 h-8 text-green-500 mb-2" />
              <h3 className="font-medium text-gray-900">Add Tenant</h3>
              <p className="text-sm text-gray-500">Register a new tenant</p>
            </button>
            <button className="p-4 border border-gray-200 rounded-lg hover:bg-gray-50 text-left">
              <CreditCard className="w-8 h-8 text-yellow-500 mb-2" />
              <h3 className="font-medium text-gray-900">Record Payment</h3>
              <p className="text-sm text-gray-500">Record a rent payment</p>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
